<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\TourDeals */

$this->title = 'Create Tour Deals';
$this->params['breadcrumbs'][] = ['label' => 'Tour Deals', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="tour-deals-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
